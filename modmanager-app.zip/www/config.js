window.CONFIG = { cfKey: '__CF_KEY__' };
